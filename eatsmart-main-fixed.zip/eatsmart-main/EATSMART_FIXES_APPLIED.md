# EatSmart fixes applied

## Security and backend
- Removed the hardcoded Google API key from `server.js`.
- `server.js` now requires `GOOGLE_API_KEY` from environment variables.
- Added safer CORS handling with `ALLOWED_ORIGINS` support.
- Fixed `/api/photo` for `node-fetch` v3 using `arrayBuffer()` and `Buffer.from()`.
- Added basic request validation for missing `lat`, `lng`, `place_id`, `ref`, and `q` values.
- Encoded query parameters before sending requests to Google APIs.

## Frontend
- Added `API_BASE_URL` using `VITE_API_BASE_URL`, with the Railway URL as the fallback.
- Replaced hardcoded backend URLs with `API_BASE_URL`.
- Fixed cuisine chips so selected cuisine filters are used during search.
- Fixed nearest sorting so it uses the current search coordinates instead of stale React state.
- Increased stored result cap from 20 to 30.
- Added 30 to the result limit buttons.
- Added an `Add price` button to each result card so the existing price modal can open.
- Cleaned duplicated overflow style setup.

## Repo clean-up
- Added `.env` and `.env.*` to `.gitignore`.
- Removed `.env` from this edited ZIP.
- Removed generated/old files from this edited ZIP: `dist`, `node_modules`, `src/EatSmart.jsx.patch`, `src/EatSmart.jsx.save`, `src/assets/react.svg`, `src/assets/vite.svg`.

## Required deployment setup
Add these variables:

Railway:
```env
GOOGLE_API_KEY=your_new_rotated_google_key
ALLOWED_ORIGINS=https://eatsmart.co.nz,http://localhost:5173
```

Vercel, optional:
```env
VITE_API_BASE_URL=https://eatsmart-production-7bcf.up.railway.app
```

## Tested
- `npm install` completed successfully.
- `npm run build` completed successfully.
- `GOOGLE_API_KEY=dummy npm start` starts the backend successfully.
